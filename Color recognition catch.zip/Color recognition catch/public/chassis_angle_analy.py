#定义一个底座运行模块
def chassis_angle_analy():
    print('进入底座运行')
    x_chassis_ball = 30.0
    y_chassis_ball = 200.0
    chassised_angle=0
    chassis_angle=0
    while (1):
        chassised_angle=math.atan(x_chassis_ball/y_chassis_ball) #得到相对弧度
        chassised_angle=chassised_angle*180/3.14   #转换成角度
        chassised_angle=90-chassised_angle/0.34   #0.34=50/17  转换成舵机绝对角度
        print('底盘绝对角度是：')
        print( chassised_angle)
        if 0<=chassised_angle<=180:
            while(chassis_angle<chassised_angle):
                servo.position(0,chassis_angle)
                chassis_angle+=1
                time.sleep(30)
            while(chassis_angle>chassised_angle):
                servo.position(0,chassis_angle)
                chassis_angle-=1
                time.sleep(30)
        else:
            print('底座角度已经超出范围！')
        break
