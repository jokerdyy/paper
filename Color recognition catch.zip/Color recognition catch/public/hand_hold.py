#手爪收紧函数
def hand_hold():
    pass
    print('手爪收紧')
    hand_angle=160
    max_hand_angle=160#手爪初始状态
    min_hand_angle=60

    while(min_hand_angle<=hand_angle):
        hand_angle+=1
        servo.position(4,hand_angle)
        time.sleep(30)
