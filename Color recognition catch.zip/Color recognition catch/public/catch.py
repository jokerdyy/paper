# 定义一个所有机械臂电机伸出去一起抓球的动作
def catch()
    chassised_angle = math.atan(x_chassis_ball / y_chassis_ball)  # 得到相对弧度


chassised_angle = chassised_angle * 180 / 3.14  # 转换成角度
chassised_angle_goal = 90 - chassised_angle / 0.34  # 0.34=50/17  转换成舵机绝对角度
print('底盘绝对角度是：')
print(chassised_angle)

# arm_angle_goal和elbow_angle_goal是目标角度
chassis_ball = math.sqrt(x_chassis ** 2 + y_chassis ** 2)
arm_angle_goal = mant.atan(chassis_high / chassis_ball)  # 角度:底座——球 & ——水平线
arm_ball = math.sqrt(chassis_ball * chassis_ball + chassis_high * chassis_high)  # 臂舵机到球距离
# 手臂和水平线角度余弦定理c*c = a*a + b*b - 2*a*b*cosC求反余弦减去臂舵机到球距离
arm_angle_goal = (math.acos((arm_long * arm_long + arm_ball * arm_ball - elbow_hand_long * elbow_hand_long) / (
            2 * arm_long * arm_ball)) - arm_angle_goal) * 180 / math.pi  # 手臂和水平线角度

elbow_angle_goal = matn.acos((elbow_hand_long * elbow_hand_long + arm_long * arm_long - arm_ball * arm_ball) / (
            2 * elbow_hand_long * arm_long)) * 180 / math.pi  # 臂肘之间的角度
elbow_angle_goal = elbow_angle_goal - 90 + arm_angle_goal  # 肘舵机于竖线的角度
print('底座目标角度:')
print('chassised_angle')
print('手臂目标角度:')
print('arm_angle_goal')
print('肘部目标角度:')
print('elbow_angle_goal')

while (
        elbow_angle != elbow_angle_goal or arm_angle != arm_angle_goal or chassis_angle != chassis_angle_goal or hand_angle != min_hand_angle)
    i = 4
    while (i >= 0)
        i = i - 1
        if i == 3 and hand_angle > min_hand_angle
            servo.position(i, hand_angle)
            hand_angle --
        elif i == 2 and elbow_angle < elbow_angle_goal
            pass
            servo.position(i, elbow_angle)
            elbow_angle ++

        elif i == 1 and arm_angle < arm_angle_goal
            pass
            servo.position(i, arm_angle)
            arm_angle ++
        elif i == 0 and chassis_angle != 90

                if chassis_angle < 90:
                    servo.position(i, chassis_angle)
                    arm_angle ++
                else:
                    servo.position(i, chassis_angle)
                    arm_angle --

