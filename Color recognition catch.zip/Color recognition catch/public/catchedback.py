#抓到球三个电机回收的动作
def catchedback():
    print('恢复位置')
    while(elbow_angle!=max_elbow_angle or arm_angle!=max_arm_angle or chassis_angle!=90)
        pass
        i=3
        while(i>=0):
        #底座，手臂，肘，手爪，对应0，1，2，3
            i=i-1
            if i==2 and elbow_angle<=max_elbow_angle
                servo.position(i,elbow_angle)
                elbow_angle++
            elif i==1 and arm_angle<=max_arm_angle
                servo.position(i,arm_angle)
                arm_angle++
            elif i==0 and chassis_angle!=90
                if chassis<90
                    ervo.position(i,chassis_angle)
                    arm_angle++
                else
                    ervo.position(i,chassis_angle)
                    arm_angle--

